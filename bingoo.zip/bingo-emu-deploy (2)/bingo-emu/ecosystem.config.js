// PM2: mantiene el bingo encendido y lo reinicia si falla.
// IMPORTANTE: una sola instancia (el estado del juego vive en memoria).
module.exports = {
  apps: [{
    name: 'bingo-emu',
    script: 'server.js',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    max_memory_restart: '600M',
    kill_timeout: 5000,
    env: { NODE_ENV: 'production' },
  }],
};
