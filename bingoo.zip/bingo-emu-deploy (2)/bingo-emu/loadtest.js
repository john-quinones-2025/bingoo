// Prueba de carga: simula N jugadores conectados y mide cuánto tardan en recibir cada bolilla.
// Uso:  ADMIN_PASS=tuclave node loadtest.js http://localhost:3000 500
// Crea usuarios 'carga0, carga1…' y al final los borra solos. Aun así, no lo uses con jugadores reales conectados.
const WebSocket = require('ws');
const base = process.argv[2] || 'http://localhost:3000', N = +process.argv[3] || 500, PASS = process.env.ADMIN_PASS || 'emu2026';
const ws_url = base.replace(/^http/, 'ws') + '/ws';
const adm = (p, b) => fetch(base + '/api/admin/' + p, { method: 'POST', headers: { 'content-type': 'application/json', 'x-admin-pass': PASS }, body: JSON.stringify(b || {}) }).then(r => r.json());
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  console.log(`Registrando ${N} usuarios de prueba…`);
  const toks = [];
  for (let i = 0; i < N; i += 25) {
    await Promise.all(Array.from({ length: Math.min(25, N - i) }, async (_, k) => {
      const n = i + k, r = await fetch(base + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ username: 'carga' + n, phone: String(900000000 + n), pin: '1234' }) });
      const j = await r.json(); if (j.token) toks.push(j.token); else console.log('login falló', j);
      await adm('assign', { username: 'carga' + n, qty: 3 });
    }));
  }
  console.log(`Conectando ${toks.length} WebSockets…`);
  let ok = 0, lat = [], expect = 0;
  const t0 = Date.now(); let sentAt = 0, errs = 0;
  toks.forEach((t, i) => setTimeout(() => {
    const ws = new WebSocket(ws_url + '?role=player&token=' + t);
    ws.on('open', () => ok++); ws.on('error', () => errs++);
    ws.on('message', d => { const s = JSON.parse(d); if (sentAt && s.drawn && s.drawn.length === expect) lat.push(Date.now() - sentAt); });
  }, Math.random() * 5000));
  await sleep(9000);
  console.log(`Conectados: ${ok}/${toks.length} (errores: ${errs})`);
  await adm('reset'); await adm('start');
  for (let b = 1; b <= 10; b++) {
    lat = []; expect = b; sentAt = Date.now(); await adm('draw', {});
    await sleep(1500);
    lat.sort((a, c) => a - c);
    console.log(`Bolilla ${b}: recibida por ${lat.length}/${ok} · mediana ${lat[lat.length >> 1] || '-'} ms · p95 ${lat[Math.floor(lat.length * .95)] || '-'} ms · máx ${lat[lat.length - 1] || '-'} ms`);
  }
  const w = await adm('wipe', { prefix: 'carga' }); console.log('Limpieza automática:', w.msg || w); process.exit(0);
})();
