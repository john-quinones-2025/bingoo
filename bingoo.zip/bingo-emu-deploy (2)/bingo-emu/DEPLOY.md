# Guía de despliegue – Bingo EMU (para el dueño del servidor)

Requisitos: servidor Linux (Ubuntu/Debian), acceso SSH con sudo, IP pública, y el dominio apuntando a esa IP
(registro DNS tipo **A**: `tudominio.com` → IP del servidor). Puertos abiertos: **22, 80, 443**. El puerto 3000 NO se abre.

## 1. Instalar lo necesario
```bash
sudo apt update && sudo apt install -y nginx certbot python3-certbot-nginx
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs
sudo npm install -g pm2
```

## 2. Subir el proyecto
Copiar la carpeta `bingo-emu` (SIN node_modules) a `/opt/bingo-emu`, y entrar:
```bash
cd /opt/bingo-emu
npm install --omit=dev
cp .env.example .env
nano .env        # <- cambiar ADMIN_PASS por una clave larga. Esta clave abre el panel del organizador.
```
- Verificar que `public/` contiene `logo.png` y `style.css` además de los .html y common.js.
- Verificar que NO existe `data.json` (así el juego empieza limpio, sin usuarios de prueba).

## 3. Arrancar con PM2 (siempre encendido)
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup          # ejecutar el comando que imprime, y luego: pm2 save
curl http://127.0.0.1:3000/health      # debe responder {"ok":1,...}
```

## 4. Nginx
1. Editar `/etc/nginx/nginx.conf`: arriba del todo añadir `worker_rlimit_nofile 65535;` y dentro de `events { }`
   poner `worker_connections 8192;` (cada jugador consume 2 conexiones en Nginx; con los valores por defecto
   se queda corto cerca de los 250-350 jugadores).
2. Copiar `nginx-bingo.conf` a `/etc/nginx/sites-available/bingo`, cambiar `tudominio.com` por el dominio real:
```bash
sudo ln -s /etc/nginx/sites-available/bingo /etc/nginx/sites-enabled/bingo
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

## 5. HTTPS (gratis)
```bash
sudo certbot --nginx -d tudominio.com -d www.tudominio.com
```
Comprobar que `https://tudominio.com` carga con candado.

## 6. Límite de archivos abiertos del sistema
```bash
echo "* soft nofile 65535" | sudo tee -a /etc/security/limits.conf
echo "* hard nofile 65535" | sudo tee -a /etc/security/limits.conf
sudo reboot     # luego comprobar: pm2 status (debe seguir 'online')
```

## 7. Firewall
```bash
sudo ufw allow OpenSSH && sudo ufw allow 'Nginx Full' && sudo ufw enable
```

## URLs
- Jugadores: `https://tudominio.com/`
- Organizador: `https://tudominio.com/admin`
- Pantalla para el live (OBS): `https://tudominio.com/live`

## Operación durante el evento
- Ver logs: `pm2 logs bingo-emu`
- Reiniciar (el estado se conserva en data.json): `pm2 restart bingo-emu`
- Copias automáticas cada 2 min en `/opt/bingo-emu/backups/` (últimas 30).
  Conviene bajar una copia de `data.json` al terminar cada ronda.
- Recuperar una copia: `pm2 stop bingo-emu && cp backups/data-XXXX.json data.json && pm2 start bingo-emu`
- Actualizar código: reemplazar archivos y `pm2 restart bingo-emu`. NO borrar data.json durante el evento.

## Prueba de carga (la víspera, antes de que se registre gente real)
```bash
ADMIN_PASS=la_clave node loadtest.js https://tudominio.com 500
# La prueba borra sus usuarios de prueba sola. Si quedó algo, el organizador usa el botón "Borrar todo" del panel /admin.
```
Debe mostrar 500/500 conectados y latencias por debajo de ~500 ms.
