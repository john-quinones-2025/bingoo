# Bingo EMU · Eco Motors Uni

Rondas: **E → M → U → APAGÓN**. Rojo y negro. Tres pantallas, un solo servidor.

| Pantalla | URL | Quién la usa |
|---|---|---|
| Jugador (móvil) | `http://localhost:3000/` | Los jugadores |
| Organizador | `http://localhost:3000/admin` | Ustedes (laptop) |
| Live (proyección / OBS) | `http://localhost:3000/live` | El público |

## 1. Instalar herramientas (Ubuntu, una sola vez)

```bash
sudo apt update
sudo apt install -y curl
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node -v   # debe mostrar v22.x
```

## 2. Inicializar el proyecto (una sola vez)

```bash
unzip bingo-emu.zip
cd bingo-emu
npm install
```

## 3. Prenderlo

```bash
ADMIN_PASS=pon_tu_clave npm start
```

(Si no pones `ADMIN_PASS`, la clave es `emu2026`.) Para apagar: `Ctrl + C`.
Todo se guarda en `data.json`: puedes apagar y prender sin perder usuarios ni cartones.
**Evento nuevo desde cero:** apaga, borra `data.json`, prende.

Probar desde un celular en la misma WiFi: `hostname -I` y abrir `http://ESA_IP:3000`.

## 4. Cómo se juega (día del evento)

1. Entra a `/admin` con la clave → **Configuración**: pega el link de YouTube del live, pon los premios y guarda.
2. Los chicos compran por el Form → verifican el pago → en **Asignar cartones** escribes el usuario y la cantidad.
   (El usuario debe haberse registrado antes en la página principal.)
3. **Iniciar ronda** → cantan bolillas: escribe el número + Enter, toca el número en el tablero, o 🎲 Sortear. **Deshacer última** corrige errores.
4. Cuando un jugador pulsa BINGO y es válido, suena un aviso en `/admin` y la pantalla live dice "VERIFICANDO BINGO…". Las bolillas se bloquean mientras tanto.
   - **Confirmar ganador** → la live muestra al ganador.
   - **Rechazar** → el juego continúa (o pasa al siguiente reclamo en cola).
5. **Siguiente ronda** → se reinician las bolillas, los cartones se mantienen.

Regla: gana el primero cuyo mensaje llegó primero y fue confirmado. No hay empates (los demás reclamos quedan descartados).

## 4b. Portal del jugador (cómo funciona)

Pantalla mínima: video arriba, el cartón ocupando casi todo, y a la derecha una columna de botones delgados (uno por cartón).

- **Doble toque** en un número = marcar / desmarcar. Se guarda aunque se recargue la página.
- **Deslizar hacia arriba** (como un reel) = cartón siguiente; hacia abajo = anterior. También se puede tocar el botón de la derecha.
- **Botones de la derecha = pila de ayuda.** Cada botón muestra el **último número cantado que aún no marcaste en ese cartón**; al marcarlo, muestra el anterior pendiente, y así. Solo dice *qué* número buscar en *qué* cartón, no dónde está. El color indica cuántos tienes pendientes: verde = 1, naranja = 2, rojo = 3 o más. (El numerito pequeño de la esquina es el número del cartón.)
- 🔥 en un botón = a ese cartón le falta 1 número (según lo que marcaste). ★ parpadeante = figura completa, pulsa BINGO.
- **⋮ (arriba a la derecha):** transferir cartones (uno o varios, con buscador de usuarios), instrucciones y **cerrar sesión**.
- **Transferencias:** solo antes de que inicie el juego. Quedan registradas y se ven en `/admin`.
- Un bingo rechazado bloquea al jugador 5 segundos (también en el servidor).

## 4c. Verificación del bingo (con la cartilla marcada)

1. Al pulsar BINGO, el celular envía **la copia de la cartilla tal como el jugador la marcó**.
2. El servidor la valida: cada celda de la figura debe estar **marcada por el jugador Y haber sido cantada**. Si el jugador no marcó, aunque ya hayan salido sus números, **no gana** (recibe un aviso).
3. Si pasa, llega a `/admin` con **dos cartillas lado a lado**: la marcada por el jugador y la del sistema (bolillas cantadas), con el veredicto y las diferencias (números marcados que no salieron, figura sin marcar). Tú confirmas o rechazas. Al confirmar se vuelve a validar.
4. En la **pantalla live** se muestra la cartilla **tal como la marcó el jugador**, con la figura resaltada y la lista de reclamos en orden de llegada con la hora exacta del servidor (hh:mm:ss.mmm). Al confirmar, dice que fue verificada contra las bolillas cantadas.

Métrica de emoción en la live: "🔥 N jugadores a 1 número de ganar".

## Logo de EMU

Copia tu logo como `public/logo.png` (idealmente fondo transparente). Se usa solo en: login del jugador, menú ⋮, panel `/admin`, cabecera de `/live` y el ícono de la pestaña. Si el archivo no existe, se muestra el texto "EMU" en su lugar.

## 5. El tema del retraso del live (importante)

YouTube retrasa el video 10 a 30 segundos. Para que en el celular la bolilla no salga **antes** de que la canten, en Configuración hay **"Retraso de bolillas en el celular"** (por defecto 15 s). Pruébenlo con un celular viendo el live y ajusten hasta que coincida.
La pantalla `/live` NO lleva retraso: es la que ustedes meten al stream.

## 6. Pantalla live con OBS

OBS → Fuentes → **Navegador** → URL `http://localhost:3000/live`, ancho 1920, alto 1080. Se escala sola a cualquier tamaño. También puedes abrirla en pantalla completa (F11) en un proyector.

## 7. Subirlo a internet (lo más rápido, gratis, sin cuenta)

Con el servidor prendido, en otra terminal:

```bash
curl -L --output cloudflared.deb https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared.deb
cloudflared tunnel --url http://localhost:3000
```

Te da un link `https://xxxx.trycloudflare.com`: ese es el que comparten con los jugadores. Tú sigues usando `/admin` y `/live` por `localhost`.
La laptop debe quedar prendida y con internet durante el evento. El link cambia cada vez que lo reinicias.

## Pruebas antes del evento

Abre 3 pestañas: jugador (crea 2 cuentas), admin (asigna cartones), live. Haz una ronda E completa.
Truco para ganar rápido en la prueba: en `/admin` el cartón de un reclamo muestra la figura; canta los números de la figura de un cartón de prueba.

## Archivos

- `server.js`: toda la lógica (usuarios, cartones, rondas, reclamos, WebSocket)
- `public/index.html`: jugador · `public/admin.html`: organizador · `public/live.html`: pantalla pública
- `data.json`: se crea solo, es tu "base de datos"
