const LET = 'BINGO';
const letterOf = n => LET[Math.floor((n - 1) / 15)];
// Conexión WebSocket con reconexión. Devuelve función now() sincronizada con el servidor.
function connect(query, onState) {
  let off = 0, dead = false;
  (function open() {
    const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws?' + query);
    ws.onmessage = e => { const s = JSON.parse(e.data); off = s.now - Date.now(); if (s.bad) dead = true; onState(s); };
    ws.onclose = () => { if (!dead) setTimeout(open, 1500); };
  })();
  return () => Date.now() + off;
}
// drawn (opcional): si se pasa, las celdas marcadas que NO han salido se señalan como 'bad'
function cardHTML(grid, marked, mask, drawn) {
  let h = '<div class="card"><div class="hd">' + [...LET].map(l => `<b>${l}</b>`).join('') + '</div><div class="grid">';
  for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
    const v = grid[r][c], free = v === 0;
    h += `<div class="cell ${free || marked.has(v) ? 'on' : ''} ${mask && mask[r][c] === '1' ? 'tgt' : ''} ${free ? 'free' : ''} ${drawn && !free && marked.has(v) && !drawn.has(v) ? 'bad' : ''}" data-n="${free ? '' : v}">${free ? '<img src="logo.png" style="width: 90%; height: auto; object-fit: contain;" alt="EMU">' : v}</div>`;
  }
  return h + '</div></div>';
}
function missing(grid, drawn, mask) {
  let m = 0;
  for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) if (mask[r][c] === '1' && grid[r][c] !== 0 && !drawn.has(grid[r][c])) m++;
  return m;
}
function miniPattern(mask, size) {
  return `<span class="mini" style="--s:${size || 14}px">` + mask.map(row => [...row].map(ch => `<i class="${ch === '1' ? 'on' : ''}"></i>`).join('')).join('') + '</span>';
}
