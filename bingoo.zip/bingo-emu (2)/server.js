// Bingo EMU - Eco Motors Uni. Servidor único (Express + WebSocket). Datos en data.json.
const express = require('express'), http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { WebSocketServer } = require('ws');
const PORT = process.env.PORT || 3000, ADMIN_PASS = process.env.ADMIN_PASS || 'emu2026';
const FILE = path.join(__dirname, 'data.json');

// Figuras (1 = celda que debe estar marcada). El centro LIBRE siempre cuenta como marcado.
const MASKS = {
  E: ['11111', '10000', '11111', '10000', '11111'],
  M: ['10001', '11011', '10101', '10001', '10001'],
  U: ['10001', '10001', '10001', '10001', '11111'],
  A: ['11111', '11111', '11111', '11111', '11111'],
};
const ROUNDS = [{ id: 'E', name: 'E' }, { id: 'M', name: 'M' }, { id: 'U', name: 'U' }, { id: 'A', name: 'APAGÓN' }];

const fresh = () => ({
  users: {}, cards: [], nextCard: 1, transfers: [],
  game: { idx: 0, status: 'waiting', drawn: [], claims: [], winner: null, winners: [], delay: 15, video: '', prizes: ['', '', '', ''] },
});
let db = fresh();
try { const d = JSON.parse(fs.readFileSync(FILE, 'utf8')); db = { ...fresh(), ...d, game: { ...fresh().game, ...d.game } }; } catch {}
let st; const save = () => { clearTimeout(st); st = setTimeout(() => fs.writeFileSync(FILE, JSON.stringify(db)), 150); };

const hash = p => crypto.createHash('sha256').update('emu' + p).digest('hex');
const nums = () => db.game.drawn.map(b => b.n);
const mask = () => MASKS[ROUNDS[db.game.idx].id];
// Valida la cartilla MARCADA por el jugador contra las bolillas cantadas: cada celda de la figura debe estar marcada Y haber salido.
function judge(grid, marked, drawn, m) {
  let notMarked = 0, wrong = 0;
  for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
    const v = grid[r][c]; if (m[r][c] !== '1' || !v) continue;
    if (!marked.has(v)) notMarked++; else if (!drawn.has(v)) wrong++;
  }
  return { notMarked, wrong, ok: !notMarked && !wrong };
}
const cardById = id => db.cards.find(c => c.id === id);
const userByToken = t => Object.values(db.users).find(u => u.token === t);

function genCard() {
  for (;;) {
    const cols = [0, 1, 2, 3, 4].map(c => {
      const a = Array.from({ length: 15 }, (_, i) => c * 15 + i + 1);
      for (let i = 14; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
      return a.slice(0, 5);
    });
    const grid = [0, 1, 2, 3, 4].map(r => [0, 1, 2, 3, 4].map(c => cols[c][r]));
    grid[2][2] = 0; // LIBRE
    const key = JSON.stringify(grid);
    if (!db.cards.some(x => JSON.stringify(x.grid) === key)) return grid;
  }
}

// ---------- Estado que se envía a cada pantalla ----------
const clients = new Set();
const miss = (grid, d, m) => { let k = 0; for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) if (m[r][c] === '1' && grid[r][c] && !d.has(grid[r][c])) k++; return k; };
// Jugadores (distintos) con algún cartón a 1 número de completar la figura. Métrica de emoción para la pantalla live.
function hotCount() {
  const g = db.game; if (!['live', 'verifying'].includes(g.status)) return 0;
  const d = new Set(nums()), m = mask(), who = new Set();
  for (const c of db.cards) if (!who.has(c.owner) && miss(c.grid, d, m) === 1) who.add(c.owner);
  return who.size;
}
// Transparencia: cartón que se está verificando + cola de reclamos con hora del servidor.
function verInfo() {
  const g = db.game; if (!['verifying', 'winner'].includes(g.status)) return null;
  const cur = g.claims.find(c => c.status === 'pending' || c.status === 'won'); if (!cur) return null;
  return { username: cur.username, card: cur.card, t: cur.t, grid: cardById(cur.cardId).grid, marked: cur.marked || [],
    queue: g.claims.map(c => ({ username: c.username, card: c.card, t: c.t, status: c.status })) };
}
const canTransfer = () => db.game.idx === 0 && db.game.status === 'waiting' && !db.game.drawn.length;
function pub() {
  const g = db.game;
  return {
    now: Date.now(), idx: g.idx, status: g.status, drawn: g.drawn, winner: g.winner, winners: g.winners, delay: g.delay, video: g.video,
    hot: hotCount(), ver: verInfo(),
    rounds: ROUNDS.map((r, i) => ({ id: r.id, name: r.name, mask: MASKS[r.id], prize: g.prizes[i] || '' })),
  };
}
function adminExtra() {
  const g = db.game;
  const online = new Set([...clients].filter(c => c.role === 'player').map(c => c.user)).size;
  return {
    online, totalCards: db.cards.length, transfers: db.transfers.slice(-8).reverse(),
    claims: g.claims.filter(c => c.status === 'pending').map(c => ({
      id: c.id, username: c.username, card: c.card, phone: db.users[c.username].phone, grid: cardById(c.cardId).grid, marked: c.marked || [], t: c.t,
    })),
    users: Object.values(db.users).map(u => ({ username: u.username, phone: u.phone, cards: db.cards.filter(c => c.owner === u.username).length }))
      .sort((a, b) => a.username.localeCompare(b.username)),
  };
}
function send(c, base) {
  if (c.ws.readyState !== 1) return;
  let p = base;
  if (c.role === 'player') p = { ...p, me: c.user, canTransfer: canTransfer(), cards: db.cards.filter(x => x.owner === c.user).map(x => ({ id: x.id, n: x.n, grid: x.grid })) };
  else if (c.role === 'admin') p = { ...p, ...adminExtra() };
  c.ws.send(JSON.stringify(p));
}
let bt; const broadcast = () => { if (bt) return; bt = setTimeout(() => { bt = null; const b = pub(); clients.forEach(c => send(c, b)); }, 40); };

// ---------- HTTP ----------
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.get('/admin', (q, r) => r.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/live', (q, r) => r.sendFile(path.join(__dirname, 'public', 'live.html')));

app.post('/api/login', (req, res) => {
  const bad = (msg, code = 400) => res.status(code).json({ msg });
  const u = String(req.body.username || '').trim().replace(/^@/, '').toLowerCase();
  let ph = String(req.body.phone || '').replace(/\D/g, ''); if (ph.length === 9) ph = '51' + ph;
  const pin = String(req.body.pin || '');
  if (!/^[a-z0-9_]{3,20}$/.test(u)) return bad('Usuario: 3 a 20 letras o números, sin espacios');
  if (ph.length < 9 || ph.length > 15) return bad('Escribe tu número de WhatsApp (ej. 987654321)');
  if (!/^\d{4,6}$/.test(pin)) return bad('El PIN debe tener de 4 a 6 números');
  let user = db.users[u];
  if (!user) {
    if (Object.values(db.users).some(x => x.phone === ph)) return bad('Ese teléfono ya está registrado con otro usuario');
    user = db.users[u] = { username: u, phone: ph, pin: hash(pin), token: crypto.randomUUID(), created: Date.now() };
    save(); broadcast();
  } else if (user.pin !== hash(pin) || user.phone !== ph) return bad('Usuario, teléfono o PIN incorrectos', 401);
  res.json({ token: user.token });
});

app.post('/api/claim', (req, res) => {
  const u = userByToken(req.body.token); if (!u) return res.status(401).json({ ok: false, msg: 'Sesión inválida' });
  const g = db.game, card = db.cards.find(c => c.id === req.body.cardId && c.owner === u.username);
  if (!card) return res.json({ ok: false, msg: 'Cartón no encontrado' });
  if (!['live', 'verifying'].includes(g.status)) return res.json({ ok: false, msg: 'No hay ronda en juego' });
  if (Date.now() < (u.coolUntil || 0)) return res.json({ ok: false, msg: 'Espera unos segundos' });
  // copia de la cartilla tal como la marcó el jugador (solo números que existen en ese cartón)
  const on = new Set(card.grid.flat());
  const marked = [...new Set((Array.isArray(req.body.marks) ? req.body.marks : []).map(Number).filter(n => n && on.has(n)))];
  const j = judge(card.grid, new Set(marked), new Set(nums()), mask());
  if (!j.ok) {
    u.coolUntil = Date.now() + 5000;
    return res.json({ ok: false, msg: j.wrong ? 'Tienes marcado un número que todavía no ha salido' : 'Aún no marcas toda la figura en tu cartilla' });
  }
  if (g.claims.some(c => c.cardId === card.id && c.status === 'pending')) return res.json({ ok: true, msg: 'Ya estás en la cola de verificación' });
  g.claims.push({ id: crypto.randomUUID(), username: u.username, cardId: card.id, card: card.n, marked, t: Date.now(), status: 'pending' });
  g.status = 'verifying'; save(); broadcast();
  res.json({ ok: true, msg: '¡Bingo enviado! Verificando…' });
});

// Búsqueda de usuarios para autocompletar (solo nombres de usuario, sin teléfonos)
app.get('/api/users', (req, res) => {
  const u = userByToken(req.query.token); if (!u) return res.status(401).json([]);
  const q = String(req.query.q || '').toLowerCase().replace(/^@/, ''); if (!q) return res.json([]);
  res.json(Object.keys(db.users).filter(n => n !== u.username && n.includes(q))
    .sort((a, b) => (a.startsWith(q) ? 0 : 1) - (b.startsWith(q) ? 0 : 1) || a.localeCompare(b)).slice(0, 6));
});

app.post('/api/transfer', (req, res) => {
  const u = userByToken(req.body.token); if (!u) return res.status(401).json({ ok: false, msg: 'Sesión inválida' });
  if (!canTransfer()) return res.json({ ok: false, msg: 'Las transferencias se cierran cuando inicia el juego' });
  const ids = [...new Set(Array.isArray(req.body.cardIds) ? req.body.cardIds : [req.body.cardId])];
  const cards = ids.map(id => db.cards.find(c => c.id === id && c.owner === u.username)).filter(Boolean);
  if (!cards.length) return res.json({ ok: false, msg: 'Elige al menos un cartón tuyo' });
  const to = db.users[String(req.body.to || '').trim().replace(/^@/, '').toLowerCase()];
  if (!to) return res.json({ ok: false, msg: 'Ese usuario no existe (debe registrarse primero)' });
  if (to.username === u.username) return res.json({ ok: false, msg: 'No puedes transferirte a ti mismo' });
  cards.forEach(card => { card.owner = to.username; db.transfers.push({ card: card.n, from: u.username, to: to.username, t: Date.now() }); });
  save(); broadcast();
  res.json({ ok: true, msg: `${cards.length} cartón(es) transferido(s) a @${to.username}` });
});

const adm = (req, res, next) => req.get('x-admin-pass') === ADMIN_PASS ? next() : res.status(401).json({ msg: 'Clave incorrecta' });
const A = (p, fn) => app.post('/api/admin/' + p, adm, (req, res) => {
  const r = fn(req.body || {});
  if (r && r.err) return res.status(400).json({ msg: r.err });
  save(); broadcast(); res.json({ ok: 1, msg: r && r.msg });
});

A('check', () => {});
A('start', () => {
  const g = db.game;
  if (g.status === 'waiting' || g.status === 'paused') g.status = 'live';
  else if (g.status === 'live') g.status = 'paused';
  else return { err: 'No se puede en este estado' };
});
A('draw', b => {
  const g = db.game; let n = +b.n;
  if (g.status !== 'live') return { err: 'Primero inicia la ronda (y no puede haber un bingo en verificación)' };
  if (!b.n) {
    const left = Array.from({ length: 75 }, (_, i) => i + 1).filter(x => !nums().includes(x));
    if (!left.length) return { err: 'Ya salieron todas' };
    n = left[Math.floor(Math.random() * left.length)];
  }
  if (!(n >= 1 && n <= 75)) return { err: 'Número entre 1 y 75' };
  if (nums().includes(n)) return { err: 'El ' + n + ' ya salió' };
  g.drawn.push({ n, t: Date.now() });
});
A('undo', () => {
  const g = db.game;
  if (!['live', 'paused'].includes(g.status)) return { err: 'No se puede deshacer ahora' };
  if (!g.drawn.length) return { err: 'No hay nada que deshacer' };
  g.drawn.pop();
});
A('claim', b => {
  const g = db.game, cl = g.claims.find(c => c.id === b.id && c.status === 'pending');
  if (!cl) return { err: 'Reclamo no encontrado' };
  let msg;
  if (b.action === 'confirm') {
    if (!judge(cardById(cl.cardId).grid, new Set(cl.marked || []), new Set(nums()), mask()).ok) { cl.status = 'rejected'; msg = 'La cartilla ya no era válida (¿deshiciste una bolilla?). Rechazado.'; }
    else {
      cl.status = 'won';
      g.winner = { username: cl.username, card: cl.card, t: Date.now(), round: ROUNDS[g.idx].name };
      g.winners.push({ ...g.winner });
      g.status = 'winner';
      g.claims.forEach(c => { if (c.status === 'pending') c.status = 'late'; });
    }
  } else cl.status = 'rejected';
  if (g.status === 'verifying' && !g.claims.some(c => c.status === 'pending')) g.status = 'live';
  return { msg };
});
A('next', () => {
  const g = db.game;
  if (g.idx >= ROUNDS.length - 1) { g.status = 'finished'; return; }
  g.idx++; Object.assign(g, { status: 'waiting', drawn: [], claims: [], winner: null });
});
A('reset', () => Object.assign(db.game, { idx: 0, status: 'waiting', drawn: [], claims: [], winner: null, winners: [] }));
A('settings', b => {
  const g = db.game;
  g.delay = Math.max(0, Math.min(120, +b.delay || 0));
  g.video = String(b.video || '').trim();
  g.prizes = [0, 1, 2, 3].map(i => String((b.prizes || [])[i] || '').slice(0, 40));
});
A('assign', b => {
  const u = db.users[String(b.username || '').trim().replace(/^@/, '').toLowerCase()];
  const q = Math.floor(+b.qty);
  if (!u) return { err: 'Ese usuario no existe. Debe registrarse primero en la página.' };
  if (!(q >= 1 && q <= 50)) return { err: 'Cantidad entre 1 y 50' };
  for (let i = 0; i < q; i++) db.cards.push({ id: crypto.randomUUID(), n: db.nextCard++, owner: u.username, grid: genCard() });
  return { msg: `${q} cartón(es) asignados a @${u.username}` };
});
A('unassign', b => {
  const mine = db.cards.filter(c => c.owner === b.username);
  if (!mine.length) return { err: 'No tiene cartones' };
  const last = mine[mine.length - 1];
  db.cards = db.cards.filter(c => c.id !== last.id);
  return { msg: `Cartón #${last.n} quitado a @${b.username}` };
});

// ---------- WebSocket ----------
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
wss.on('connection', (ws, req) => {
  const q = new URL(req.url, 'http://x').searchParams, role = q.get('role');
  const reject = () => { ws.send(JSON.stringify({ bad: 1, now: Date.now() })); ws.close(); };
  let user = null;
  if (role === 'admin') { if (q.get('pass') !== ADMIN_PASS) return reject(); }
  else if (role === 'player') { const u = userByToken(q.get('token')); if (!u) return reject(); user = u.username; }
  else if (role !== 'live') return ws.close();
  const c = { ws, role, user }; clients.add(c);
  ws.on('close', () => { clients.delete(c); broadcast(); });
  ws.on('error', () => {});
  send(c, pub()); broadcast();
});
setInterval(() => clients.forEach(c => c.ws.readyState === 1 && c.ws.ping()), 25000);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\nBingo EMU listo (clave admin: ${ADMIN_PASS})`);
  console.log(`  Jugadores:  http://localhost:${PORT}/`);
  console.log(`  Organizador: http://localhost:${PORT}/admin`);
  console.log(`  Pantalla live: http://localhost:${PORT}/live\n`);
});
